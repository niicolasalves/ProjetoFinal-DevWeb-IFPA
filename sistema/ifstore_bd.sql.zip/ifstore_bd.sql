-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 18-Out-2020 às 17:14
-- Versão do servidor: 10.4.13-MariaDB
-- versão do PHP: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `ifstore_bd`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `clientes`
--

CREATE TABLE `clientes` (
  `id_cliente` int(10) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `cpf` varchar(14) NOT NULL,
  `endereco` varchar(100) DEFAULT NULL,
  `endereco_num` varchar(5) DEFAULT NULL,
  `bairro` varchar(50) DEFAULT NULL,
  `complemento` varchar(100) DEFAULT NULL,
  `cidade` varchar(30) DEFAULT NULL,
  `uf` varchar(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `clientes`
--

INSERT INTO `clientes` (`id_cliente`, `nome`, `cpf`, `endereco`, `endereco_num`, `bairro`, `complemento`, `cidade`, `uf`) VALUES
(5, 'Nicolas Alves', '000.000.000-00', 'Rua Moxoto', '30', 'Vila Peninsula', '', 'Tucurui', 'PA'),
(12, 'Cliente de Teste', '000.000.000-00', '', '', '', '', '', ''),
(13, 'Francisco Antônio', '123.456.789-00', 'Rua do Cliente', '10', 'Vila', '', 'Tucurui', 'PA');

-- --------------------------------------------------------

--
-- Estrutura da tabela `pedidos`
--

CREATE TABLE `pedidos` (
  `id_pedido` int(10) NOT NULL,
  `data` datetime NOT NULL,
  `cod_cliente` int(10) NOT NULL,
  `valor_pedido` decimal(6,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `pedidos`
--

INSERT INTO `pedidos` (`id_pedido`, `data`, `cod_cliente`, `valor_pedido`) VALUES
(1, '2020-10-17 00:17:25', 5, '5000.00'),
(2, '2020-10-17 00:37:40', 12, '8000.00'),
(3, '2020-10-17 01:59:16', 13, '500.00'),
(4, '2020-10-17 01:59:51', 5, '5500.00'),
(5, '2020-10-18 12:12:37', 5, '8000.00');

-- --------------------------------------------------------

--
-- Estrutura da tabela `pedido_produtos`
--

CREATE TABLE `pedido_produtos` (
  `cod_pedido` int(10) NOT NULL,
  `cod_produto` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `pedido_produtos`
--

INSERT INTO `pedido_produtos` (`cod_pedido`, `cod_produto`) VALUES
(2, 1),
(2, 3),
(1, 1),
(3, 4),
(4, 4),
(4, 1),
(5, 1),
(5, 3);

-- --------------------------------------------------------

--
-- Estrutura da tabela `produtos`
--

CREATE TABLE `produtos` (
  `id_produto` int(10) NOT NULL,
  `tipo` varchar(30) NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `descricao` text DEFAULT NULL,
  `valor` decimal(6,2) NOT NULL,
  `caracteristicas` text NOT NULL,
  `estoque` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `produtos`
--

INSERT INTO `produtos` (`id_produto`, `tipo`, `titulo`, `descricao`, `valor`, `caracteristicas`, `estoque`) VALUES
(1, 'laptops', 'Samsung Odyssey Core i7 8GB 1TB', 'Isso é um teste de cadastro!!', '5000.00', '{\"Nome do Fabricante\":\"Samsung\",\"Tamanho de Tela\":\"15,6\",\"Mem\\u00f3ria RAM\":\"8GB\",\"Armazenamento HD\":\"1TB\",\"Tipo de Processador\":\"Intel Core i7 7700HQ\"}', 2),
(3, 'desktops', 'Computador Gamer Core i5 8GB 1TB GTX 1050 Ti', '', '3000.00', '{\"Nome do Fabricante\":\"IFStore\",\"Mem\\u00f3ria RAM\":\"8GB\",\"Armazenamento HD\":\"1TB\",\"Tipo de Processador\":\"Intel Core i5\"}', 8),
(4, 'impressoras', 'Impressora HP Deskjet 1060', 'Isso é um teste de inserir um produto', '500.00', '{\"Nome do Fabricante\":\"HP\",\"Tipo de Impressora\":\"Laser\",\"Multifuncional\":\"Sim\"}', 3);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id_cliente`);

--
-- Índices para tabela `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id_pedido`),
  ADD KEY `vendas_FK_clientes` (`cod_cliente`);

--
-- Índices para tabela `pedido_produtos`
--
ALTER TABLE `pedido_produtos`
  ADD KEY `pedidos_produtos_FK` (`cod_pedido`),
  ADD KEY `pedidos_produtos_FK_1` (`cod_produto`);

--
-- Índices para tabela `produtos`
--
ALTER TABLE `produtos`
  ADD PRIMARY KEY (`id_produto`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id_cliente` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de tabela `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `id_pedido` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `produtos`
--
ALTER TABLE `produtos`
  MODIFY `id_produto` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `pedidos`
--
ALTER TABLE `pedidos`
  ADD CONSTRAINT `vendas_FK_clientes` FOREIGN KEY (`cod_cliente`) REFERENCES `clientes` (`id_cliente`) ON UPDATE CASCADE;

--
-- Limitadores para a tabela `pedido_produtos`
--
ALTER TABLE `pedido_produtos`
  ADD CONSTRAINT `pedidos_produtos_FK` FOREIGN KEY (`cod_pedido`) REFERENCES `pedidos` (`id_pedido`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pedidos_produtos_FK_1` FOREIGN KEY (`cod_produto`) REFERENCES `produtos` (`id_produto`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
